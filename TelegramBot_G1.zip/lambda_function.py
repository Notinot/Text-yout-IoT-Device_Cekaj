import json
import urllib3
import paho.mqtt.client as mqtt
import time

BOT_TOKEN = "7737824358:AAFBF7DU55csaZ-x-eLx2VHqrTwExDRmpXo"
mqtt_broker = "54.205.109.222"
mqtt_port = 1883
mqtt_publish_topic = "test/topic"  # The topic to which commands are sent
mqtt_reply_topic = "temp/topic"    # The topic from which responses are received


def sendReply(chat_id, message):
    reply = {
        "chat_id": chat_id,
        "text": message
    }

    http = urllib3.PoolManager()
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    encoded_data = json.dumps(reply).encode('utf-8')

    response = http.request(
        'POST', url, body=encoded_data, headers={'Content-Type': 'application/json'}
    )

    print(f"*** Reply Sent: {encoded_data}, Response Status: {response.status}")


def on_message(client, userdata, msg):
    userdata['message'] = msg.payload.decode()
    print(f"*** MQTT message received on {msg.topic}: {userdata['message']}")


def on_connect(client, userdata, flags, rc):
    print(f"*** Connected to MQTT broker with result code {rc}")
    client.subscribe(mqtt_reply_topic)  # Subscribe to the new reply topic


def lambda_handler(event, context):
    try:
        # Parse incoming event body
        body = json.loads(event['body'])
        if 'message' not in body:
            print("*** No 'message' field in the body")
            return {
                'statusCode': 200,
                'body': json.dumps('No message to process')
            }

        chat_id = body['message']['chat']['id'] 
        user_name = body['message']['from'].get('username', 'unknown')
        message_text = body['message'].get('text', '')

        print(f"*** chat id: {chat_id}")
        print(f"*** user name: {user_name}")
        print(f"*** message text: {message_text}")

        if message_text == "/start":
            sendReply(chat_id, "This is a Test of Group 1")
        elif message_text == "/temp":
            print("*** Processing '/temp' command")
            state = {'message': None}
            client = mqtt.Client(userdata=state)
            client.on_connect = on_connect
            client.on_message = on_message

            try:
                print(f"*** Connecting to MQTT broker {mqtt_broker}:{mqtt_port}")
                client.connect(mqtt_broker, mqtt_port, 60)
                client.loop_start()

                # Send the '/temp' command to the IoT device
                temp_message = "/temp"
                print(f"*** Publishing '/temp' message to topic {mqtt_publish_topic}")
                client.publish(mqtt_publish_topic, temp_message)

                # Wait for the response with a timeout
                timeout = 15
                start_time = time.time()
                while state['message'] is None and time.time() - start_time < timeout:
                    time.sleep(0.1)

                if state['message']:
                    print(f"*** MQTT message received: {state['message']}")
                    sendReply(chat_id, state['message'])
                else:
                    print("*** No MQTT message received within timeout")
                    sendReply(chat_id, "No response from IoT device in time.")
            except Exception as mqtt_error:
                print(f"*** MQTT error: {mqtt_error}")
                sendReply(chat_id, "Failed to connect to IoT device.")
            finally:
                client.loop_stop()
                client.disconnect()
        else:
            sendReply(chat_id, "Unknown Command")

        return {
            'statusCode': 200,
            'body': json.dumps('Message processed successfully')
        }

    except Exception as e:
        print(f"*** Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Internal server error: {str(e)}")
        }
